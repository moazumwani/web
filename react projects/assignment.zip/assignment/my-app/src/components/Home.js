import React, { useState } from "react";
import * as ReactBootStrap from "react-bootstrap";
import { BrowserRouter as Switch, Link } from "react-router-dom";
// import { FormControl, Button, Form } from 'react-bootstrap'
import PostData from "./warehouses.json";
function Multi() {
    const [searchText, setSearchText] = useState("");
    const [data, setData] = useState(PostData);


    // handle change event of search input
    const handleChange = (value) => {
        setSearchText(value);
        filterData(value);
    };

    // filter records by search text
    const filterData = (value) => {
        const lowercasedValue = value.toLowerCase().trim();
        if (lowercasedValue === "")
            setData(PostData);
        else {
            const filteredData = PostData.filter((item) => {
                return Object.keys(item).some((key) => {
                    return item[key].toString().toLowerCase().includes(lowercasedValue);
                })


            });
            setData(filteredData);
        }
    };

    return (
        <div className="App">
            <h>List of Warehouses</h><br></br>
             Search:{" "}

            <input
                style={{ marginLeft: 5 }}
                type="text"
                placeholder="Type to search..."
                value={searchText}
                onChange={(e) => handleChange(e.target.value)}
            />
            <div className="box-container">
                {data.map((d, i) => {
                    return (
                        <div key={i} className="box" style={{ backgroundColor: d.color }}>
                            <b>Name: </b>
                            {d.name}
                            <br />
                            <b>City: </b>
                            {d.city}
                            <br />
                            <b>Cluster: </b>
                            {d.cluster}
                            <br />

                            <b>id: </b>
                            {d.id}
                            <br />
                            <b>Space available: </b>
                            {d.space_available}
                            <br />
                            <b>Type: </b>
                            {d.type}
                            <br />

                        </div>
                    );
                })}
                <div className="clearboth"></div>
                {data.length === 0 && <span>No records found to display!</span>}
            </div>
        </div>
    );
}

export default Multi;
